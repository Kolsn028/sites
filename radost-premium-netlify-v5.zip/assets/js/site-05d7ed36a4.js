(() => {
  'use strict';

  const $ = (selector, context = document) => context.querySelector(selector);
  const $$ = (selector, context = document) => [...context.querySelectorAll(selector)];

  const header = $('#siteHeader');
  const menuToggle = $('.menu-toggle');
  const mobileMenu = $('#mobileMenu');
  const year = $('#year');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = matchMedia('(pointer: fine)').matches;
  const saveData = navigator.connection?.saveData === true;

  if (year) year.textContent = new Date().getFullYear();

  const toggleHeaderState = () => header?.classList.toggle('scrolled', scrollY > 10);
  toggleHeaderState();
  addEventListener('scroll', toggleHeaderState, { passive: true });

  function setMenu(open) {
    if (!menuToggle || !mobileMenu) return;
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    mobileMenu.hidden = !open;
  }

  if (menuToggle && mobileMenu) {
    setMenu(false);
    menuToggle.addEventListener('click', () => setMenu(menuToggle.getAttribute('aria-expanded') !== 'true'));
    $$('#mobileMenu a').forEach(link => link.addEventListener('click', () => setMenu(false)));
    addEventListener('resize', () => {
      if (innerWidth > 992) setMenu(false);
    }, { passive: true });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') setMenu(false);
    });
  }

  const revealItems = $$('[data-reveal]');
  if (reducedMotion || !('IntersectionObserver' in window)) {
    revealItems.forEach(item => item.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -5% 0px' });
    revealItems.forEach(item => revealObserver.observe(item));
  }

  const navLinks = $$('.desktop-nav a[href^="#"]');
  const observedSections = navLinks.map(link => $(link.getAttribute('href'))).filter(Boolean);
  if ('IntersectionObserver' in window && observedSections.length) {
    const navObserver = new IntersectionObserver(entries => {
      const visible = entries.filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!visible) return;
      navLinks.forEach(link => link.classList.toggle('is-active', link.getAttribute('href') === `#${visible.target.id}`));
    }, { rootMargin: '-25% 0px -62% 0px', threshold: [0, .15, .4] });
    observedSections.forEach(section => navObserver.observe(section));
  }

  const programSelect = $('#programSelect');
  const ageGroup = $('#ageGroup');
  $$('.program-action[data-program]').forEach(button => {
    button.addEventListener('click', () => {
      const program = button.dataset.program || '';
      if (programSelect) {
        const option = [...programSelect.options].find(item => item.textContent.trim() === program);
        if (option) programSelect.value = option.value;
      }
      $('#form')?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'center' });
      setTimeout(() => programSelect?.focus(), reducedMotion ? 0 : 550);
    });
  });

  const pickerMap = {
    '1-4': { title: 'Раннее развитие и индивидуальная поддержка', text: 'Начните с консультации: администратор уточнит навыки ребёнка и подскажет подходящий формат.', age: '1–3 года', program: '' },
    '4-7': { title: 'Подготовка к школе, чтение и ментальная математика', text: 'Для этого возраста особенно актуальны базовые учебные навыки, чтение, счёт и уверенный старт перед школой.', age: '5–7 лет', program: 'Подготовка к школе' },
    '7-10': { title: 'Репетиторство, каллиграфия и математика', text: 'Можно закрыть школьные пробелы, улучшить почерк и укрепить уверенность в учебных задачах.', age: '7–10 лет', program: 'Репетиторство' },
    '11-16': { title: 'Индивидуальная помощь по школьным задачам', text: 'Оптимальный старт — консультация и выбор индивидуального маршрута под текущие пробелы и цели.', age: '11–16 лет', program: 'Репетиторство' }
  };

  const pickerResult = $('#pickerResult');
  const pickerButtons = $$('.picker-options [data-age]');
  pickerButtons.forEach(button => {
    button.addEventListener('click', () => {
      const data = pickerMap[button.dataset.age];
      if (!data || !pickerResult) return;
      pickerButtons.forEach(item => item.classList.toggle('is-active', item === button));
      pickerResult.replaceChildren();
      const label = document.createElement('span');
      const title = document.createElement('strong');
      const text = document.createElement('p');
      const apply = document.createElement('button');
      label.textContent = 'Рекомендуем начать';
      title.textContent = data.title;
      text.textContent = data.text;
      apply.className = 'picker-apply';
      apply.type = 'button';
      apply.textContent = 'Перейти к записи →';
      apply.addEventListener('click', () => {
        if (ageGroup && data.age) ageGroup.value = data.age;
        if (programSelect && data.program) programSelect.value = data.program;
        $('#form')?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'center' });
      });
      pickerResult.append(label, title, text, apply);
    });
  });

  const galleryButtons = $$('.gallery-item[data-image]');
  const lightbox = $('#lightbox');
  const lightboxImage = $('#lightboxImage');
  const lightboxCaption = $('#lightboxCaption');
  const lightboxClose = $('.lightbox-close');
  let galleryTrigger = null;

  if (lightbox && lightboxImage && lightboxCaption) {
    galleryButtons.forEach(button => {
      button.addEventListener('click', () => {
        galleryTrigger = button;
        const imgInside = $('img', button);
        lightboxImage.src = button.dataset.image || imgInside?.src || '';
        lightboxImage.alt = imgInside?.alt || button.dataset.caption || '';
        lightboxCaption.textContent = button.dataset.caption || '';
        if (typeof lightbox.showModal === 'function') lightbox.showModal();
      });
    });

    const closeLightbox = () => {
      if (!lightbox.open) return;
      lightbox.close();
      lightboxImage.removeAttribute('src');
      galleryTrigger?.focus();
    };

    lightboxClose?.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', event => {
      const rect = lightbox.getBoundingClientRect();
      const inside = event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
      if (!inside) closeLightbox();
    });
  }

  if (finePointer && !reducedMotion && !saveData) {
    const root = $('[data-parallax-root]');
    if (root) {
      const layers = $$('[data-parallax]', root);
      let raf = 0;
      let targetX = 0;
      let targetY = 0;

      const render = () => {
        raf = 0;
        layers.forEach(layer => {
          const amount = Number(layer.dataset.parallax || 0);
          layer.style.translate = `${targetX * amount}px ${targetY * amount}px`;
        });
      };

      root.addEventListener('pointermove', event => {
        const rect = root.getBoundingClientRect();
        targetX = ((event.clientX - rect.left) / rect.width - .5) * 14;
        targetY = ((event.clientY - rect.top) / rect.height - .5) * 12;
        if (!raf) raf = requestAnimationFrame(render);
      }, { passive: true });

      root.addEventListener('pointerleave', () => {
        targetX = 0;
        targetY = 0;
        if (!raf) raf = requestAnimationFrame(render);
      }, { passive: true });
    }
  }
})();
