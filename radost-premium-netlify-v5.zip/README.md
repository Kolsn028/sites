# Радость познания — Premium V5 / Netlify

Готовая статическая production-сборка главной страницы образовательного центра «Радость познания».

## Что изменено в V5

### Premium UI / UX
- новая светлая brand-система: коралловый primary + мягкие жёлтый, mint, sky и violet акценты;
- hero полностью перестроен вокруг реальных фотографий учеников;
- реальный портрет руководителя оформлен как editorial-блок «О центре»;
- карточки направлений получили возраст, свой цветовой тон, микроиконки и CTA;
- добавлен быстрый подбор направления по возрасту;
- добавлены trust-ribbon, блок подхода, премиальная галерея и FAQ;
- единый `:focus-visible`, крупные touch targets и адаптив от 320 px до больших экранов;
- reveal-анимации через `IntersectionObserver`, лёгкий pointer-parallax только для fine pointer;
- `prefers-reduced-motion`, touch/no-hover и Save-Data учитываются в JS/CSS.

### Исправления по аудиту
1. Исправлен баг мобильного меню: `[hidden]` больше не перебивается CSS.
2. Hero больше не показывает «стену вместо детей»: главная композиция использует горизонтальное групповое фото; кадрирование управляется отдельно.
3. Удалены 3 неиспользуемых `AISelect_*.jpg` исходника (около 1.18 MB).
4. CSP ужесточён: `script-src 'self'`, без `unsafe-inline`. Также вынесены inline-стили служебных страниц, поэтому `style-src` тоже только `'self'`.
5. Дублирующее cache-правило удалено из `netlify.toml`; кеш задаётся только в `_headers`.
6. `#fff7f0` используется одинаково в `theme-color`, manifest, 404, privacy и thank-you.
7. `og-cover.jpg` теперь отдельный social cover 1200×630, а не случайный кроп hero.

### Netlify
- форма `lead` использует Netlify Forms + honeypot `bot-field`;
- PHP не нужен;
- HTML: `must-revalidate`;
- fingerprint CSS/JS: `immutable, max-age=31536000`;
- изображения кешируются на 30 дней, чтобы их можно было обновлять без годового stale-cache;
- `_headers`, `_redirects`, `netlify.toml`, `robots.txt`, `sitemap.xml`, manifest включены.

## Деплой

1. Распаковать архив.
2. Загрузить содержимое папки в Netlify Drop или подключить репозиторий.
3. Publish directory: `.`
4. Build command не нужен.
5. После первого production deploy открыть Netlify → Forms и убедиться, что форма `lead` появилась.

## Основные файлы
- `index.html` — главная;
- `assets/css/site-*.css` — основной fingerprint CSS;
- `assets/js/site-*.js` — основной fingerprint JS;
- `privacy/index.html` — политика;
- `thank-you/index.html` — страница после формы;
- `_headers` — security/cache headers;
- `_redirects` — короткие redirects к секциям;
- `netlify.toml` — publish config.

## Реальные фотографии
- `real-kids-group.*` — ученики на занятии;
- `real-kids-awards.*` — ученики с дипломами;
- `student.webp` — портрет ученика с прозрачным фоном;
- `founder.*` — руководитель центра;
- `og-cover.jpg` — отдельное превью для соцсетей.
